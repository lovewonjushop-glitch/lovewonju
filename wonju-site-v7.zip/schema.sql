-- 원주사장님 힘내세요! D1 관광지 다국어 자동 동기화 테이블 (v4)
-- 적용 방법: wrangler d1 execute <DB_NAME> --remote --file=schema.sql

CREATE TABLE IF NOT EXISTS places (
  id TEXT PRIMARY KEY,
  lang TEXT NOT NULL DEFAULT 'ko',
  content_id TEXT,
  content_type_id TEXT,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  dong TEXT DEFAULT '',
  address TEXT DEFAULT '',
  phone TEXT DEFAULT '',
  hours TEXT DEFAULT '',
  closed TEXT DEFAULT '',
  desc TEXT DEFAULT '',
  transport TEXT DEFAULT '',
  facilities_json TEXT DEFAULT '[]',
  official_url TEXT DEFAULT '',
  source_label TEXT DEFAULT '한국관광공사 TourAPI',
  photo_credit TEXT DEFAULT '한국관광공사 TourAPI · 공공누리',
  img TEXT DEFAULT '',
  lat REAL,
  lng REAL,
  has_coords INTEGER DEFAULT 0,
  detail_loaded INTEGER DEFAULT 0,
  updated_at INTEGER NOT NULL,
  UNIQUE(lang, content_id)
);

CREATE INDEX IF NOT EXISTS idx_places_lang_cat ON places(lang, category);
CREATE INDEX IF NOT EXISTS idx_places_updated ON places(updated_at DESC);
