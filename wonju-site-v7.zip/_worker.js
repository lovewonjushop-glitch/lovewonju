// Cloudflare Pages Advanced Mode worker (v3 보안 강화 + TourAPI 자동 동기화)
const CATEGORIES = ['음식점', '카페·디저트', '미용·뷰티', '운동', '꽃·공방', '가게·쇼핑', '반려동물', '배움·키즈', '기타 서비스'];
const HANDLE_RE = /^@[A-Za-z0-9._]{1,30}$/;

const SHOP_CATEGORIES = ['한식·음식점', '카페·베이커리', '전통시장·반찬', '미용·생활서비스', '소매·공방'];
const SHOP_DONGS = ['중앙동·일산동', '무실동', '단계동', '반곡동(혁신도시)', '지정면(기업도시)', '단구동', '문막읍', '흥업면·소초면'];
const MAX_PHOTOS = 5;
const MAX_PHOTO_BYTES = 2 * 1024 * 1024;
const MAX_TOTAL_PHOTO_BYTES = MAX_PHOTOS * MAX_PHOTO_BYTES;
const MAX_PENDING_SHOPS = 200;

const PAGE_CSP = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline' https://oapi.map.naver.com https://*.pstatic.net",
  "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net",
  "font-src 'self' https://cdn.jsdelivr.net data:",
  "img-src 'self' data: blob: https://tong.visitkorea.or.kr https://tile.openstreetmap.org https://*.pstatic.net https://*.naver.net https://*.naver.com",
  "connect-src 'self' https://*.naver.com https://*.naver.net https://*.pstatic.net",
  "frame-ancestors 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "object-src 'none'"
].join('; ');

function withSecurityHeaders(res, isApi = false) {
  const h = new Headers(res.headers);
  h.set('X-Content-Type-Options', 'nosniff');
  h.set('X-Frame-Options', 'DENY');
  h.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  h.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  h.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  if (isApi) {
    h.set('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'");
  } else {
    const ct = h.get('content-type') || '';
    if (ct.includes('text/html')) h.set('Content-Security-Policy', PAGE_CSP);
  }
  return new Response(res.body, { status: res.status, statusText: res.statusText, headers: h });
}

function json(data, status = 200, extra = {}) {
  return withSecurityHeaders(
    new Response(JSON.stringify(data), {
      status,
      headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...extra }
    }),
    true
  );
}

function checkOrigin(request) {
  const origin = request.headers.get('origin');
  if (!origin || origin === 'null') return false;
  try {
    return new URL(origin).origin === new URL(request.url).origin;
  } catch {
    return false;
  }
}

function clean(s, max) {
  return String(s ?? '').replace(/[\u0000-\u001f\u007f<>]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
}

function cleanMultiline(s, max) {
  return String(s ?? '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f<>]/g, ' ').trim().slice(0, max);
}

function stripHtml(s, max = 600) {
  return String(s ?? '')
    .replace(/<br\s*\/?>/gi, ' ')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, max);
}

async function sha256(text) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('');
}

async function timingSafeSecretMatch(provided, expected) {
  if (!provided || !expected) return false;
  const a = new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(String(provided))));
  const b = new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(String(expected))));
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
  return diff === 0;
}

async function getIpHash(request, env) {
  if (!env.IP_SALT) {
    console.error('[security] IP_SALT environment variable is not configured.');
    return null;
  }
  const ip = request.headers.get('cf-connecting-ip') || 'unknown';
  return sha256(`${env.IP_SALT}:${ip}`);
}

async function verifyTurnstile(token, request, env) {
  if (!env.TURNSTILE_SECRET_KEY) return true;
  if (!token || typeof token !== 'string') return false;
  try {
    const form = new URLSearchParams();
    form.append('secret', env.TURNSTILE_SECRET_KEY);
    form.append('response', token);
    const ip = request.headers.get('cf-connecting-ip');
    if (ip) form.append('remoteip', ip);
    const r = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', { method: 'POST', body: form });
    if (!r.ok) return false;
    const data = await r.json();
    return Boolean(data && data.success);
  } catch (e) {
    console.error('[turnstile] verification failed:', e && e.message);
    return false;
  }
}

function isValidJpeg(bytes) {
  if (!bytes || bytes.length < 4 || bytes.length > MAX_PHOTO_BYTES) return false;
  const hasSOI = bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
  const hasEOI = bytes[bytes.length - 2] === 0xff && bytes[bytes.length - 1] === 0xd9;
  return hasSOI && hasEOI;
}

// ===== 1. 스레드 순위 API =====
async function listApproved(env) {
  const { results } = await env.DB.prepare(
    `SELECT id, name, category, subtag, handle, followers, approved_at, updated_at
       FROM threads_accounts WHERE status = 'approved'
      ORDER BY followers DESC, approved_at ASC LIMIT 500`
  ).all();
  const updatedAt = results.reduce((m, r) => Math.max(m, r.updated_at || r.approved_at || 0), 0) || null;
  return json({ accounts: results, updatedAt }, 200, { 'cache-control': 'public, max-age=60' });
}

async function submit(request, env) {
  if (!checkOrigin(request)) return json({ error: '허용되지 않은 요청입니다.' }, 403);

  const ipHash = await getIpHash(request, env);
  if (!ipHash) return json({ error: '서버 보안 설정이 완료되지 않았습니다.' }, 503);

  const now = Date.now();
  const recent = await env.DB.prepare('SELECT COUNT(*) AS c FROM threads_accounts WHERE ip_hash = ? AND created_at > ?')
    .bind(ipHash, now - 3600 * 1000).first();
  if (recent && recent.c >= 3) return json({ error: '잠시 후 다시 신청해 주세요. (1시간에 3건까지)' }, 429);

  const pending = await env.DB.prepare("SELECT COUNT(*) AS c FROM threads_accounts WHERE status = 'pending'").first();
  if (pending && pending.c >= 500) return json({ error: '현재 신청이 많아 접수를 잠시 멈췄어요.' }, 503);

  const raw = await request.text();
  if (raw.length > 2000) return json({ error: '요청이 너무 큽니다.' }, 413);
  let body;
  try { body = JSON.parse(raw); } catch { return json({ error: '잘못된 요청입니다.' }, 400); }
  if (!body || typeof body !== 'object') return json({ error: '잘못된 요청입니다.' }, 400);

  if (body.website) return json({ ok: true }, 201);

  if (!(await verifyTurnstile(body.turnstileToken, request, env))) {
    return json({ error: '자동화 방지 확인에 실패했어요. 새로고침 후 다시 시도해 주세요.' }, 403);
  }

  const name = clean(body.name, 40);
  const category = clean(body.category, 20);
  const subtag = clean(body.subtag, 20) || category;
  let handle = clean(body.handle, 32).replace(/\s/g, '');
  if (handle && !handle.startsWith('@')) handle = '@' + handle;
  const followers = Math.floor(Number(body.followers));

  if (!name) return json({ error: '가게명을 입력해 주세요.' }, 400);
  if (!CATEGORIES.includes(category)) return json({ error: '분야를 선택해 주세요.' }, 400);
  if (!HANDLE_RE.test(handle)) return json({ error: '스레드 아이디는 영문·숫자·점·밑줄만 쓸 수 있어요. (예: @wonju_bake)' }, 400);
  if (!Number.isFinite(followers) || followers < 100 || followers > 100000000) return json({ error: '팔로워 수는 100명 이상으로 입력해 주세요.' }, 400);

  try {
    await env.DB.prepare(
      `INSERT INTO threads_accounts (name, category, subtag, handle, followers, status, created_at, ip_hash)
       VALUES (?, ?, ?, ?, ?, 'pending', ?, ?)`
    ).bind(name, category, subtag, handle, followers, now, ipHash).run();
  } catch (e) {
    if (String(e && e.message).includes('UNIQUE')) return json({ error: '이미 신청되었거나 등록된 스레드 계정입니다.' }, 409);
    console.error('[api/threads] D1 insert error:', e && e.message);
    return json({ error: '저장 중 문제가 생겼어요. 잠시 후 다시 시도해 주세요.' }, 500);
  }
  return json({ ok: true }, 201);
}

// ===== 2. 가게 등록 신청 API: D1 저장 + 관리자 메일(Resend) =====
function esc(s) {
  return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function toBase64(bytes) {
  let bin = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  return btoa(bin);
}

function buildMailHtml(d, photoCount) {
  const row = (k, v) => `<tr><td style="padding:8px 12px;background:#f3f4f6;font-weight:bold;width:130px;vertical-align:top">${esc(k)}</td><td style="padding:8px 12px;vertical-align:top">${esc(v || '-').replace(/\n/g, '<br>')}</td></tr>`;
  return `<div style="font-family:Apple SD Gothic Neo,Malgun Gothic,sans-serif;max-width:640px">
    <h2 style="margin:0 0 4px">새 가게 등록 신청</h2>
    <p style="margin:0 0 14px;color:#6b7280">${esc(d.name)} · 사진 ${photoCount}장 첨부</p>
    <table style="border-collapse:collapse;width:100%;border:1px solid #e5e7eb;font-size:14px">
      ${row('가게 이름', d.name)}${row('업종', d.category)}${row('동네', d.dong)}${row('가게 주소', d.address)}
      ${row('가게 전화', d.phone)}${row('영업시간', d.hours)}${row('한 줄 소식', d.notice)}${row('가게 소개', d.intro)}
      ${row('스레드 계정', d.threads)}${row('담당자 연락처', d.contact)}
    </table>
    <p style="margin-top:14px;color:#6b7280;font-size:12px">신청 번호 #${d.id} · 확인 후 담당자 연락처로 회신해 주세요. (D1 shop_submissions 테이블에도 저장됨)</p>
  </div>`;
}

async function sendAdminMail(env, d, photos) {
  if (!env.RESEND_API_KEY || !env.ADMIN_EMAIL) {
    console.error('[mail] RESEND_API_KEY or ADMIN_EMAIL is not configured.');
    return false;
  }
  const body = {
    from: env.MAIL_FROM || '원주사장님 <onboarding@resend.dev>',
    to: [env.ADMIN_EMAIL],
    subject: `[원주사장님] 새 가게 등록 신청: ${d.name}`,
    html: buildMailHtml(d, photos.length),
    attachments: photos.map((p, i) => ({ filename: `photo-${i + 1}.jpg`, content: toBase64(p) }))
  };
  const r = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  if (!r.ok) console.error('[mail] Resend API returned status:', r.status);
  return r.ok;
}

async function submitShop(request, env) {
  if (!checkOrigin(request)) return json({ error: '허용되지 않은 요청입니다.' }, 403);

  const ipHash = await getIpHash(request, env);
  if (!ipHash) return json({ error: '서버 보안 설정이 완료되지 않았습니다.' }, 503);

  const now = Date.now();
  const recent = await env.DB.prepare('SELECT COUNT(*) AS c FROM shop_submissions WHERE ip_hash = ? AND created_at > ?')
    .bind(ipHash, now - 3600 * 1000).first();
  if (recent && recent.c >= 3) return json({ error: '잠시 후 다시 신청해 주세요. (1시간에 3건까지)' }, 429);

  const pending = await env.DB.prepare("SELECT COUNT(*) AS c FROM shop_submissions WHERE status = 'new'").first();
  if (pending && pending.c >= MAX_PENDING_SHOPS) return json({ error: '현재 신청이 많아 접수를 잠시 멈췄어요.' }, 503);

  const len = Number(request.headers.get('content-length') || 0);
  if (len > 12 * 1024 * 1024) return json({ error: '사진 용량이 너무 큽니다. 사진 수를 줄여 주세요.' }, 413);

  let form;
  try { form = await request.formData(); } catch { return json({ error: '잘못된 요청입니다.' }, 400); }
  if (form.get('website')) return json({ ok: true }, 201);

  if (!(await verifyTurnstile(form.get('cf-turnstile-response'), request, env))) {
    return json({ error: '자동화 방지 확인에 실패했어요. 새로고침 후 다시 시도해 주세요.' }, 403);
  }

  const d = {
    name: clean(form.get('name'), 40),
    category: clean(form.get('category'), 20),
    dong: clean(form.get('dong'), 20),
    address: clean(form.get('address'), 100),
    phone: clean(form.get('phone'), 20),
    hours: clean(form.get('hours'), 80),
    notice: clean(form.get('notice'), 80),
    intro: cleanMultiline(form.get('intro'), 500),
    threads: clean(form.get('threads'), 32),
    contact: clean(form.get('contact'), 40)
  };
  if (!d.name) return json({ error: '가게 이름을 입력해 주세요.' }, 400);
  if (!SHOP_CATEGORIES.includes(d.category)) return json({ error: '업종을 선택해 주세요.' }, 400);
  if (!SHOP_DONGS.includes(d.dong)) return json({ error: '동네를 선택해 주세요.' }, 400);
  if (!d.address) return json({ error: '가게 주소를 입력해 주세요.' }, 400);
  if (!d.notice) return json({ error: '한 줄 소식을 입력해 주세요.' }, 400);
  if (!d.contact || d.contact.replace(/\D/g, '').length < 8) return json({ error: '확인 연락을 받을 전화번호를 입력해 주세요.' }, 400);
  if (form.get('consent') !== 'yes') return json({ error: '개인정보 수집·이용에 동의해 주세요.' }, 400);

  const files = form.getAll('photos').filter(f => f && typeof f === 'object' && 'arrayBuffer' in f && f.size > 0);
  if (files.length > MAX_PHOTOS) return json({ error: `사진은 최대 ${MAX_PHOTOS}장까지 올릴 수 있어요.` }, 400);
  const photos = [];
  let totalPhotoBytes = 0;
  for (const f of files) {
    if (f.size > MAX_PHOTO_BYTES) return json({ error: '사진 한 장은 2MB 이하여야 해요.' }, 413);
    const bytes = new Uint8Array(await f.arrayBuffer());
    totalPhotoBytes += bytes.length;
    if (totalPhotoBytes > MAX_TOTAL_PHOTO_BYTES) return json({ error: '사진 총 용량이 너무 큽니다. 사진 수를 줄여 주세요.' }, 413);
    if (!isValidJpeg(bytes)) return json({ error: '올바른 JPG 사진만 올릴 수 있어요.' }, 400);
    photos.push(bytes);
  }

  let id;
  try {
    const res = await env.DB.prepare(
      `INSERT INTO shop_submissions (name, category, dong, address, phone, hours, notice, intro, threads, contact, photo_count, status, created_at, ip_hash)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'new', ?, ?)`
    ).bind(d.name, d.category, d.dong, d.address, d.phone, d.hours, d.notice, d.intro, d.threads, d.contact, photos.length, now, ipHash).run();
    id = res.meta.last_row_id;
  } catch (e) {
    console.error('[api/shops] D1 insert error:', e && e.message);
    return json({ error: '저장 중 문제가 생겼어요. 잠시 후 다시 시도해 주세요.' }, 500);
  }

  let mailed = false;
  try {
    mailed = await sendAdminMail(env, { ...d, id }, photos);
  } catch (e) {
    console.error('[api/shops] sendAdminMail error:', e && e.message);
    mailed = false;
  }
  try {
    await env.DB.prepare('UPDATE shop_submissions SET email_sent = ? WHERE id = ?').bind(mailed ? 1 : 0, id).run();
  } catch (e) {
    console.error('[api/shops] email_sent update error:', e && e.message);
  }
  return json({ ok: true }, 201);
}

// ===== 3. 원주 관광지 다국어 자동 API (한국관광공사 TourAPI -> D1 캐시) =====
const SUPPORTED_LANGS = ['ko', 'en', 'ja', 'zh'];
const TOUR_SERVICES = {
  ko: 'KorService2',
  en: 'EngService2',
  ja: 'JpnService2',
  zh: 'ChsService2'
};

function normLang(raw) {
  const s = String(raw || 'ko').toLowerCase().slice(0, 2);
  return SUPPORTED_LANGS.includes(s) ? s : 'ko';
}

function tourBaseUrl(env, lang = 'ko') {
  if (lang === 'ko' && env.TOUR_API_BASE) return String(env.TOUR_API_BASE).replace(/\/+$/, '');
  const svc = TOUR_SERVICES[normLang(lang)] || 'KorService2';
  return `https://apis.data.go.kr/B551011/${svc}`;
}

function encodeTourKey(key) {
  const s = String(key || '').trim();
  return s.includes('%') ? s : encodeURIComponent(s);
}

async function callTourApi(env, operation, params = {}, lang = 'ko') {
  const qs = new URLSearchParams({
    MobileOS: 'WEB',
    MobileApp: 'LoveWonju',
    _type: 'json',
    ...params
  });
  const url = `${tourBaseUrl(env, lang)}/${operation}?serviceKey=${encodeTourKey(env.TOUR_API_KEY)}&${qs.toString()}`;
  const r = await fetch(url, { headers: { Accept: 'application/json' } });
  if (!r.ok) throw new Error(`TourAPI ${operation} HTTP ${r.status}`);
  const data = await r.json();
  const body = data && data.response && data.response.body;
  const items = body && body.items && body.items.item;
  return Array.isArray(items) ? items : items ? [items] : [];
}

function normalizeTourImage(url) {
  const s = String(url || '').trim();
  if (!s) return '';
  if (s.startsWith('http://tong.visitkorea.or.kr/')) return s.replace('http://', 'https://');
  if (s.startsWith('https://tong.visitkorea.or.kr/')) return s;
  return '';
}

function extractDong(addr) {
  const m = String(addr || '').match(/원주시\s+([가-힣0-9]+(?:읍|면|동))/);
  return m ? m[1] : '원주';
}

function mapTourCategory(contentTypeId, title) {
  if (String(title || '').includes('시장')) return '전통시장';
  if (String(contentTypeId) === '14') return '역사·문화';
  if (String(contentTypeId) === '38') return '전통시장';
  return '관광지';
}

function rowToPlace(r) {
  let facilities = [];
  try { facilities = JSON.parse(r.facilities_json || '[]'); } catch {}
  return {
    id: r.id,
    contentId: r.content_id || null,
    contentTypeId: r.content_type_id || null,
    name: r.name,
    category: r.category,
    dong: r.dong || '원주',
    address: r.address || '',
    phone: r.phone || '',
    hours: r.hours || '방문 전 공식 안내 확인',
    closed: r.closed || '방문 전 공식 안내 확인',
    desc: r.desc || '',
    transport: r.transport || '',
    facilities: Array.isArray(facilities) ? facilities : [],
    officialUrl: r.official_url || '',
    sourceLabel: r.source_label || '한국관광공사 TourAPI',
    photoCredit: r.photo_credit || '한국관광공사 TourAPI · 공공누리',
    img: r.img || '',
    lat: r.lat != null ? Number(r.lat) : null,
    lng: r.lng != null ? Number(r.lng) : null,
    hasCoords: Boolean(r.has_coords && r.lat != null && r.lng != null),
    detailLoaded: Boolean(r.detail_loaded),
    updatedAt: r.updated_at || null
  };
}

async function listPlaces(env, lang = 'ko') {
  const safeLang = normLang(lang);
  try {
    const { results } = await env.DB.prepare(
      `SELECT id, lang, content_id, content_type_id, name, category, dong, address, phone, hours, closed, desc, transport,
              facilities_json, official_url, source_label, photo_credit, img, lat, lng, has_coords, detail_loaded, updated_at
         FROM places
        WHERE lang = ?
        ORDER BY has_coords DESC, updated_at DESC
        LIMIT 200`
    ).bind(safeLang).all();
    const updatedAt = results.reduce((m, r) => Math.max(m, r.updated_at || 0), 0) || null;
    return json({ places: results.map(rowToPlace), updatedAt, source: results.length ? 'd1' : 'empty' }, 200, { 'cache-control': 'public, max-age=300' });
  } catch (e) {
    // places 테이블이 아직 생성되지 않은 초기 상태에서도 프론트엔드가 기본 데이터로 안전하게 폴백
    console.error('[api/places] list error:', e && e.message);
    return json({ places: [], updatedAt: null, source: 'fallback' }, 200, { 'cache-control': 'public, max-age=60' });
  }
}

async function getPlaceDetail(id, env) {
  let row;
  try {
    row = await env.DB.prepare(
      `SELECT id, lang, content_id, content_type_id, name, category, dong, address, phone, hours, closed, desc, transport,
              facilities_json, official_url, source_label, photo_credit, img, lat, lng, has_coords, detail_loaded, updated_at
         FROM places WHERE id = ?`
    ).bind(id).first();
  } catch (e) {
    console.error('[api/places/:id] query error:', e && e.message);
    return json({ error: '장소 정보를 불러올 수 없습니다.' }, 404);
  }
  if (!row) return json({ error: '장소를 찾을 수 없습니다.' }, 404);

  // TourAPI 상세(개요·이용시간·휴무일·주차)를 최초 1회 지연 로딩 후 D1에 캐싱
  if (!row.detail_loaded && row.content_id && env.TOUR_API_KEY) {
    try {
      const rowLang = normLang(row.lang || 'ko');
      const [commonItems, introItems] = await Promise.all([
        callTourApi(env, 'detailCommon2', { contentId: row.content_id }, rowLang),
        row.content_type_id ? callTourApi(env, 'detailIntro2', { contentId: row.content_id, contentTypeId: row.content_type_id }, rowLang) : Promise.resolve([])
      ]);
      const c = commonItems[0] || {};
      const it = introItems[0] || {};
      const desc = stripHtml(c.overview, 600) || row.desc;
      const hours = stripHtml(it.usetime || it.usetimeculture || it.opentime, 160) || row.hours;
      const closed = stripHtml(it.restdate || it.restdateculture || it.restdateshopping, 120) || row.closed;
      const phone = stripHtml(it.infocenter || it.infocenterculture || it.infocentershopping || c.tel, 60) || row.phone;
      const homepageMatch = String(c.homepage || '').match(/https?:\/\/[^\s"'<>]+/);
      const officialUrl = homepageMatch ? homepageMatch[0] : row.official_url;
      const facs = [];
      if (it.parking || it.parkingculture || it.parkingshopping) facs.push(`주차: ${stripHtml(it.parking || it.parkingculture || it.parkingshopping, 40)}`);
      if (it.chkbabycarriage || it.chkbabycarriageculture) facs.push(`유모차 대여: ${stripHtml(it.chkbabycarriage || it.chkbabycarriageculture, 20)}`);
      if (it.chkpet || it.chkpetculture) facs.push(`반려동물: ${stripHtml(it.chkpet || it.chkpetculture, 20)}`);
      const facilitiesJson = facs.length ? JSON.stringify(facs) : row.facilities_json;
      const now = Date.now();

      await env.DB.prepare(
        `UPDATE places
            SET desc = ?, hours = ?, closed = ?, phone = ?, official_url = ?, facilities_json = ?, detail_loaded = 1, updated_at = ?
          WHERE id = ?`
      ).bind(desc, hours, closed, phone, officialUrl, facilitiesJson, now, row.id).run();

      row = { ...row, desc, hours, closed, phone, official_url: officialUrl, facilities_json: facilitiesJson, detail_loaded: 1, updated_at: now };
    } catch (e) {
      console.error('[api/places/:id] TourAPI hydrate error:', e && e.message);
    }
  }
  return json({ place: rowToPlace(row) }, 200, { 'cache-control': 'public, max-age=300' });
}

async function resolveWonjuSigunguCode(env, areaCode) {
  if (env.TOUR_SIGUNGU_CODE) return String(env.TOUR_SIGUNGU_CODE).trim();
  const items = await callTourApi(env, 'areaCode2', { areaCode, numOfRows: '50', pageNo: '1' });
  const wonju = items.find(x => String(x.name || '').includes('원주'));
  return wonju && wonju.code ? String(wonju.code) : '9';
}

async function syncPlaces(request, env) {
  if (!env.SYNC_SECRET) return json({ error: 'SYNC_SECRET이 설정되지 않았습니다.' }, 503);
  if (!env.TOUR_API_KEY) return json({ error: 'TOUR_API_KEY가 설정되지 않았습니다.' }, 503);

  const auth = request.headers.get('authorization') || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7).trim() : '';
  if (!(await timingSafeSecretMatch(token, env.SYNC_SECRET))) {
    return json({ error: '인증에 실패했습니다.' }, 401);
  }

  const url = new URL(request.url);
  const langParam = url.searchParams.get('lang');
  const langs = langParam ? [normLang(langParam)] : SUPPORTED_LANGS;
  const areaCode = String(env.TOUR_AREA_CODE || '32'); // 강원특별자치도
  const sigunguCode = await resolveWonjuSigunguCode(env, areaCode);
  const now = Date.now();
  const counts = {};

  for (const lang of langs) {
    // 다국어 TourAPI: 국문(12,14) / 영·일·중(76: 관광지, 78: 문화시설)
    const contentTypes = lang === 'ko' ? ['12', '14'] : ['76', '78'];
    let upserted = 0;
    for (const contentTypeId of contentTypes) {
      let items = [];
      try {
        items = await callTourApi(env, 'areaBasedList2', {
          areaCode,
          sigunguCode,
          contentTypeId,
          arrange: 'Q',
          numOfRows: '60',
          pageNo: '1'
        }, lang);
      } catch (e) {
        console.error(`[sync:${lang}] ${contentTypeId} error:`, e && e.message);
        continue;
      }
      for (const item of items) {
        const contentId = String(item.contentid || '').trim();
        const name = clean(item.title, 100);
        if (!contentId || !name) continue;
        const id = `tour-${lang}-${contentId}`;
        const address = clean([item.addr1, item.addr2].filter(Boolean).join(' '), 160);
        const dong = lang === 'ko' ? extractDong(address) : 'Wonju';
        const category = (contentTypeId === '14' || contentTypeId === '78') ? '역사·문화' : mapTourCategory(contentTypeId, name);
        const phone = clean(item.tel, 40);
        const img = normalizeTourImage(item.firstimage || item.firstimage2);
        const lat = Number(item.mapy);
        const lng = Number(item.mapx);
        const hasCoords = Number.isFinite(lat) && Number.isFinite(lng) && lat > 33 && lat < 40 && lng > 124 && lng < 132 ? 1 : 0;

        await env.DB.prepare(
          `INSERT INTO places (id, lang, content_id, content_type_id, name, category, dong, address, phone, img, lat, lng, has_coords, source_label, photo_credit, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'KTO TourAPI', 'Korea Tourism Organization TourAPI', ?)
           ON CONFLICT(lang, content_id) DO UPDATE SET
             name = excluded.name,
             category = excluded.category,
             dong = excluded.dong,
             address = excluded.address,
             phone = CASE WHEN excluded.phone != '' THEN excluded.phone ELSE places.phone END,
             img = CASE WHEN excluded.img != '' THEN excluded.img ELSE places.img END,
             lat = excluded.lat,
             lng = excluded.lng,
             has_coords = excluded.has_coords,
             updated_at = excluded.updated_at`
        ).bind(id, lang, contentId, contentTypeId, name, category, dong, address, phone, img, hasCoords ? lat : null, hasCoords ? lng : null, hasCoords, now).run();
        upserted++;
      }
    }
    counts[lang] = upserted;
  }

  return json({ ok: true, areaCode, sigunguCode, counts, updatedAt: now }, 200);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/api/threads') {
      if (!env.DB) return json({ error: 'DB가 연결되지 않았습니다.' }, 503);
      try {
        if (request.method === 'GET') return await listApproved(env);
        if (request.method === 'POST') return await submit(request, env);
        return json({ error: '지원하지 않는 요청입니다.' }, 405, { allow: 'GET, POST' });
      } catch (e) {
        console.error('[api/threads] unhandled error:', e && e.message);
        return json({ error: '서버 오류가 발생했습니다.' }, 500);
      }
    }
    if (url.pathname === '/api/shops') {
      if (!env.DB) return json({ error: 'DB가 연결되지 않았습니다.' }, 503);
      if (request.method !== 'POST') return json({ error: '지원하지 않는 요청입니다.' }, 405, { allow: 'POST' });
      try {
        return await submitShop(request, env);
      } catch (e) {
        console.error('[api/shops] unhandled error:', e && e.message);
        return json({ error: '서버 오류가 발생했습니다.' }, 500);
      }
    }
    if (url.pathname === '/api/places') {
      if (!env.DB) return json({ places: [], updatedAt: null, source: 'fallback' }, 200);
      if (request.method !== 'GET') return json({ error: '지원하지 않는 요청입니다.' }, 405, { allow: 'GET' });
      return await listPlaces(env, url.searchParams.get('lang') || 'ko');
    }
    if (url.pathname.startsWith('/api/places/')) {
      if (!env.DB) return json({ error: 'DB가 연결되지 않았습니다.' }, 503);
      if (request.method !== 'GET') return json({ error: '지원하지 않는 요청입니다.' }, 405, { allow: 'GET' });
      const id = decodeURIComponent(url.pathname.slice('/api/places/'.length));
      if (!id || id.length > 64) return json({ error: '잘못된 요청입니다.' }, 400);
      return await getPlaceDetail(id, env);
    }
    if (url.pathname === '/api/admin/sync-places') {
      if (!env.DB) return json({ error: 'DB가 연결되지 않았습니다.' }, 503);
      if (request.method !== 'POST') return json({ error: '지원하지 않는 요청입니다.' }, 405, { allow: 'POST' });
      try {
        return await syncPlaces(request, env);
      } catch (e) {
        console.error('[api/admin/sync-places] error:', e && e.message);
        return json({ error: '동기화 중 오류가 발생했습니다.' }, 500);
      }
    }
    const assetRes = await env.ASSETS.fetch(request);
    return withSecurityHeaders(assetRes, false);
  }
};
